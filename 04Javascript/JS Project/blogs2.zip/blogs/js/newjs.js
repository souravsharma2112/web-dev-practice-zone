let data = `Lorem ipsum dolor sit amet consectetur adipisicing elit. Incidunt debitis aliquid vero deleniti, provident qui voluptatem, tempora temporibus consequatur mollitia dolorem sunt quod accusamus quo, maxime dolore. Quisquam officiis harum voluptas cupiditate asperiores non, cumque nemo sunt provident distinctio amet eius! Modi, dolor autem. Enim.`

const wordArr = data.split(" ").slice(0,10).join(" ") + "..."
console.log(wordArr)